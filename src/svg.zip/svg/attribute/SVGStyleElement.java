/*
 * SVGStyleElement.java
 *
 * Created on 2008/09/19, 14:09
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package svg.attribute;

import svg.SVGElement;

/**
 *
 * @author i002060
 */
public class SVGStyleElement implements SVGElement{
    
    /** Creates a new instance of SVGStyleElement */
    public SVGStyleElement() {
    }

    public String getXML() {
        return "";
    }
    
}
