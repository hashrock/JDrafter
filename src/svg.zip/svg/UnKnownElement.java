/*
 * UnKnownElement.java
 *
 * Created on 2008/09/12, 10:19
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package svg;

/**
 *
 * @author i002060
 */
public class UnKnownElement implements SVGElement{
    
    /** Creates a new instance of UnKnownElement */
    public UnKnownElement() {
    }

    public String getXML() {
        return "";
    }
    
}
