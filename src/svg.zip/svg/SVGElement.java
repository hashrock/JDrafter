/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package svg;

import java.io.Serializable;

/**
 *
 * @author takashi
 */
public interface SVGElement extends Serializable {
    public String getXML();
}
