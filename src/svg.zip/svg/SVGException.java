/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package svg;

/**
 *
 * @author takashi
 */
public class SVGException extends Exception{
    public SVGException(String message){
        super(message);
    }
}
